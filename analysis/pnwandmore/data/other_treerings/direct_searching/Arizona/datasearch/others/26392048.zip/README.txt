---------------------------------------------
# New radiocarbon tree-ring datasets for "The timing of the ca-660 BCE Miyake solar-proton event constrained to between 664 and 663 BCE"

Preferred citation (DataCite format):

  Panyushkina, Irina P; Jull, A J Timothy; Molnár, Mihaly; Varga, Tamás; Kontul’, 
  Ivan; Hantemirov, Rashit; et al. (2024). New radiocarbon tree-ring datasets 
  for "The timing of the ca-660 BCE Miyake solar-proton event constrained to 
  between 664 and 663 BCE".
  University of Arizona Research Data Repository.
  Dataset. https://doi.org/10.25422/azu.data.26392048


Corresponding Author:
  Irina P Panyushkina, Laboratory of Tree-Ring Research, ipanyush@arizona.edu


License:
  CC BY 4.0


DOI:
  https://doi.org/10.25422/azu.data.26392048



---------------------------------------------
## Summary

Extreme solar energetic particle events, known as Miyake events, are rare
phenomena observed by cosmogenic isotopes, with only six documented. The
timing of the ca. 660 BCE Miyake event remains undefined until now. Here, we
assign its occurrence to 664-663 BCE through new radiocarbon measurements in
gymnosperm larch tree rings from arctic-alpine biomes (Yamal and Altai). Using
a 22-box carbon cycle model and Bayesian statistics, we calculate the
radiocarbon production rate during the event that is 3.2-4.8 times higher than
the average solar modulation, and comparable to the 774-775 CE solar-proton
event. The prolonged radiocarbon signature manifests a 12‰ rise over two
years. The non-uniform signal in the tree rings is likely driven by the low
rate of CO2 gas exchange between the trees and the ambient atmosphere, and the
high residence time of radiocarbon in the post-event stratosphere. We caution
about using the event's pronounced signature for precise single-year-dating.

This is a dataset of radiocarbon measurements in gymnosperm larch tree rings 
from arctic-alpine biomes (Yamal and Altai). The data was created to investigate 
the timing and structure of the extreme solar energetic particle event ca. 660 
BCE (also called the Miyake event). The development of this dataset was funded 
by NASA grant 80NSSC21K1426. 

Irina P. Panyushkina (1)*, A. J. Timothy Jull (2,3), Mihaly Molnár (3), Tamás Varga (3), 
Ivan Kontul’ (4), Rashit Hantemirov (5,6), Vladymir Kukarskih (5,6), Igor Sljusarenko (7), Vladymir Myglan (8), Valerie Livina (9)
1 Laboratory of Tree-Ring Research, University of Arizona, Tucson, AZ, USA
2 Department of Geosciences, University of Arizona, Tucson, AZ, USA 
3 Isotope Climatology and Environmental Research Centre, Institute for Nuclear Research, Debrecen, HU
4 Department of Mathematics, Physics and Informatics, Comenius University, Bratislava, SK
5 Institute of Plant and Animal Ecology UB RAS, Yekaterinburg, RF
6 Ural Institute of Humanities, Ural Federal University, Yekaterinburg, RF
7 Institute of Archaeology and Ethnography SB RAS, Novosibirsk, RF
8 School for the Humanities, Siberian Federal University, Krasnoyarsk, RF 
9 Data Science Department, National Physical Laboratory, Teddington, UK

The authors' roles: 
I.P. and A.J.T.J. designed the study. 
Tree-ring samples were cross-dated and provided by I.S., V.M., R.H. and V.K. 
Radiocarbon content was measured by M.M., T.V. and I.K. These authors contributed equally. 
Radiocarbon modeling was done by I.P. and V.L. 
The paper was written by I.P. together with A.J.T.J. and VL. 
All the authors approved the text.



---------------------------------------------
## Files and Folders

Panyushkina etal 2024_Radiocarbondataset_ca660BCE.pdf:
Supplementary table and figures for the paper "The timing of the ca-660 BCE Miyake
solar-proton event constrained to between 664 and 663 BCE".

Panyushkina_et al New radiocarbon tree-ring datsets_ca660 BCE COMMSENV-24-0029DSupplData_Panyushkina etal al.csv:
Corresponds to Table 1 in the PDF. The dataset contains two annual 
series of normalized delta 14C (d14C) measurements of larch tree-ring 
samples, in per mil (‰) and error of the 14C measurements (sig_d14c). 
The tree rings come from two regions of Northern Eurasia: Yamal and 
Altai. 



---------------------------------------------
## Materials and Methods

Altai larch: 
This 48-year 14C series (685-638 BCE) was developed from Larix sibirica conifer 
rings of Scythian archeological timbers excavated at the Ulandryk IV cemetery 
[Panyushkina et al. 2007]. The Ulandryk IV is located in the upper tree-line 
ecotone of the Chuysky Range, Altai Mountains, Russia. Specimen # 19116 was 
collected from Kurgan-1 and cross-dated with the Mongun Taiga tree-ring 
chronology [Myglan et al. 2012]. The growth season in the Altai’s extremely 
continental climate rounds a little over 3 months between late May and early 
September. The cellulose was pretreated with the acid-base-acid bleaching, and 
14C was measured at the ICER AMS facility of the Hertelendi Laboratory of 
Environmental Studies (HEKAL) in Debrecen, Hungary, following the standard 
protocols of this laboratory [Molnár et al. 2013]. 


Yamal larch: 
This 21-year series spans from 671 to 651 BCE. The rings of Larix sibirica 
subfossil wood (specimen #1902) from fluvial deposits of the Yamal Peninsula, 
Russia, were dated with the Yamal multimillennial tree-ring chronology 
[Hantemirov et al. 2021]. The site location is the taiga-tundra ecotone in cold 
semi-arid climate with less than 3-month growing season from June to August. The 
14C of the prepared rings was measured at ICER AMS Laboratory in Debrecen 
following the same procedure used for the Altai larch 
series 


Delat 14C calculation 
Radiocarbon analysis was performed on annually resolved time series of d14C in 
astronomical year numbering (Astro years) then converted to BCE. Δ14C is 
calculated as: 

Δ14C = 1000(Feλt – 1) (1.1) 

where λ is the true decay constant of 14C (1.209 x 10-4) based on the half-life 
of 5730 yr, and t is the known age of the ring sample by dendrochronology. The 
fraction of modern carbon, F, is defined as the 14C/12C ratio relative to the 
“modern” 14C activity set to 1950 AD, which is defined as 0.95 of the 
14C/12C ratio of the oxalic-I standard [Stuiver et al.1977] or 0.7459 of the 
international oxalic-II standard (SRM-4990C), see Donahue et al. [1990] 

Panyushkina, I.P., Sljusarenko, I.Y., Bikov, N.I. & Bogdanov, E. Floating larch 
tree-ring chronologies from archaeological timbers in the Russian Altai between 
800 BC and 800 AD. Radiocarbon 49(2), 693–702 (2007) 

Myglan, V.C., Oydupaa, O.C. & Vaganov, E.A. Development of 2,367-year tree-ring 
chronology for the Altai-Sayan region (Mongun-Taiga mountain range). Archeology, 
Ethnography and Anthropology of Eurasia 3, 51 (2012) 

Molnár, M. et al. Status report of the new AMS 14C sample preparation lab of 
the Hertelendi Laboratory of Environmental Studies (Debrecen, Hungary). 
Radiocarbon 55, 665–676 (2013) 

Hantemirov, R. M. et al. An 8768-year Yamal Tree-ring Chronology as a tool for 
paleoecological reconstructions. Russ. J. Ecol. 52, 419–427 (2021) 

Stuiver, M. & Polach, H.A. Discussion: Reporting of 14C data. Radiocarbon 19, 
355–363 (10.1017/S0033822200003672, 1977) 

Donahue, D.J., Linick, T.W. & Jull, A.J.T. Isotope ratio and background 
corrections for accelerator mass spectrometry radiocarbon measurements. 
Radiocarbon 32(2), 135–42 (1990)



---------------------------------------------
## Additional Notes

Links:
  - https://doi.org/10.1017/S0033822200042582
  - https://doi.org/10.1016/j.aeae.2012.11.009
  - https://doi.org/10.1017/S0033822200057829
  - https://doi.org/10.1134/S1067413621050088
  - https://doi.org/10.1017/S0033822200003672
  - https://doi.org/10.1017/S0033822200040121
  - https://doi.org/10.1017/RDC.2017.59
  - https://doi.org/10.1038/s41598-019-57273-2
