
This Dataset Collection file archive data and supporting information for the following publication

Liu Y et al. 2023 Decoupling of height growth and drought or pest resistance tradeoffs is revealed through 
multiple common-garden experiments of lodgepole pine. Evolution. (in press)

If you have any queries about the data, please contact the corresponding author.

*** the "raw_data" document includes the following columns
  * col 1 - col 11: experimental design information
self, dad, and mum: pedigree information used to estimate genetic effects
site: progeny test site
proc: population original location, i.e., provenance	
codg: unique coding for each individual
rep: replicate
set
tree: tree number
row and col: row and column used to calculate spatial effect
  * col 12 - col 23: all measured traits (refer to Methods S1 for measurement details)
HT09,23,30,35: height (m) measured at age 9, 23, 30, and 35, respectively
Drought resistance02 and 10: drought resistance in 2002 and 2010, an index measuring basal area increment ratio in a drought yr vs. over 4 prior-yrs on average
Declining: an index measuring basal area increment ratio in five years before vs. after a drought event
C13: delta carbon 13	
WGR30_2, 36_6, and 36_4: western gall rust severity level counted at age 30 and 36 using 2, 6, and 4 tiers for classification, respectively.
MPB_suitability: mountain pine beetle suitability scores based on chemical profiling

*** Programming scripts written in R language for data analysis include
  * functions.R
  * analysis.R

*** the "snp_subset.updownstream" document is a sequence data file in fasta format, which curate putative SNPs of 
genetic tradeoffs and their flanking sequences identified in this work.