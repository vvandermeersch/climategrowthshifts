#cleaning
rm(list = ls())
gc()

#working directory setup
setwd("/home/yl859/Desktop")

#import software packages
#installation for some packages needing a medium
if(!require(devtools)) install.packages('devtools')
devtools::install_github('famuvie/breedR')

if(!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
BiocManager::install("GeneticsPed")

#required libraries
lib = c("plyr","tidyverse","tidyr","dplyr","seqRFLP","ggplot2","grid","readxl","MCMCpack",
        "ggrepel","latex2exp","breedR","GeneticsPed","MCMCglmm","parallel","coda")

#install and load libraries
for (i in lib){
  if (i %in% installed.packages ()[,"Package"] == F){
    install.packages(i)
  }
  library(i, character.only = TRUE)
}
rm(i,lib)

source("functions.R")

#data import
dat = read.table("/home/yl859/Downloads/raw_data.txt", header = TRUE)

dat = dat[,c("site","proc","self","mum","dad","codg","rep","set","col","row",
             "HT35","C13","WGR36_04","MPB_suitability")]#these are four focal traits; do the same for the other traits
names(dat)[(ncol(dat)-3):ncol(dat)] = c('HT','C13','WGR','MPB')

dat = dat %>% as.data.frame %>% 
  mutate(self = as.numeric(as.character(self)),
         dad = as.numeric(as.character(dad)),
         mum = as.numeric(as.character(mum)),
         site = as.character(site),
         rep = as.character(rep),
         set = as.character(set),
         proc = as.character(proc),
         animal = as.factor(codg),
         codg = as.factor(codg)
         )

glimpse(dat)

################################
###   phenotype adjustment   ###
################################
target.trait = c('HT','C13','WGR','MPB')

set.seed(9999)

rho.grid = expand.grid(rho_r = seq(.4, .9999999, length = 20), rho_c = seq(.4, .9999999, length = 20))
#range [-1,1]; after a coarse search using the range, I found that best rhos fall within [0.4, 1] across traits

PHENOADJUST(dat,target.trait,rho.grid,rhos=NULL,step=1)
#Note: this step is time-consuming, taking up to 3.5 days to complete for all 4 traits * 4 sites of the data. Ignore warnings!

#after 'step=1', extract rhos from output and then construct a list of rhos as follows
rhos = list(c(0.7473684,0.9052631),c(0.9999999,0.9999999),c(0.9999999,0.9999999), c(0.9999999,0.9999999),#site 1: trait 1 to 4
            c(0.9368420,0.9684210),c(0.9999999,0.9999999),c(0.9999999,0.9999999),c(0.9999999,0.9999999),#site 2: trait 1 to 4
            c(0.9999999,0.6526315),c(0.9999999,0.9999999),c(0.9999999,0.9999999),c(0.9999999,0.9999999),#site 3: trait 1 to 4
            c(0.9999999,0.9999999),c(0.9999999,0.9999999),c(0.9999999,0.9999999),c(0.9999999,0.9999999)#site 4: trait 1 to 4
            )

PHENOADJUST(dat,target.trait,rho.grid=NULL,rhos,step=2)#Ignore warnings!

#############################################################################
### Test for signal of divergent/ stabilizing selection vs. genetic drift ### 
#############################################################################
setwd("C:/Users/yliu2011/Desktop/pine")

#import data
# snp.dat => genotype data
# traits => phenotype data

detectCores()
afm = mclapply(1:16, function(i) {
  do.all(snp.dat,85000, 55000,30)
}, mc.cores=20)
#or
afm = do.all(snp.dat,85000,55000,30)
#drawing trace of coancestry matrix theta, assess convergence
#Monte Carlo traces of the coancestry coefficients
#=> the Markov chains have mixed well enough or not
#head(do.all)
names(afm)#"theta" "fst" "kappa" "alpha"
theta = afm$theta#posterior of coancestry coefficients
dim(theta)
viz.theta(afm$theta)
summary(afm$fst)#posterior estimate of fst


load("H:/Project - GWAS (conifers)/Results/intermediate data/driftsel_afm.RData")
theta = afm$theta

head(MH)
{samp = MH(theta, ped, covars, traits, 85000, 55000, 30, alt=T)#all 4 traits
  samp.all = samp
  print("scenario for all 4 traits completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,2)], 85000, 55000, 30, alt=T)#HT
  samp.HT = samp
  print("scenario for HT completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,3)], 85000, 55000, 30, alt=T)#C13
  samp.C13 = samp
  print("scenario for C13 completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,4)], 85000, 55000, 30, alt=T)#WGR
  samp.WGR = samp
  print("scenario for WGR completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,5)], 85000, 55000, 30, alt=T)#MPB
  samp.MPB = samp
  print("scenario for MPB completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,2,3)], 85000, 55000, 30, alt=T)#HT+C13
  samp.HT.C13 = samp
  print("scenario for HT+C13 completed!")}
{samp = MH(theta, ped, covars, traits[,c(1,4,5)], 85000, 55000, 30, alt=T)#WGR+MPB
  samp.WGR.MPB = samp
  print("scenario for WGR+MPB completed!")}

neut.test(samp$pop.ef, samp$G, samp$theta, silent=F)#=> signal of selection (S)
#also show posterior trace of S, of which the S test statistic is the mean

par(mfrow=c(2,3),mar=c(4,4,4,1))
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(1,2), main="Trait space", siz = 0.5)
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(1,3), main="Trait space", siz = 0.5)
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(1,4), main="Trait space", siz = 0.5)
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(2,3), main="Trait space", siz = 0.5)
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(2,4), main="Trait space", siz = 0.5)
viz.traits(samp$fixed.ef, samp$pop.ef, samp$G, samp$theta, c(3,4), main="Trait space", siz = 0.5)

save(afm, #samp.all, #samp.HT, #samp.C13, samp.WGR, samp.MPB, samp.HT.C13, samp.WGR.MPB,
     file = "E:/Conifers/output_selection/driftsel_afm.RData")
save(samp.all, samp.HT, samp.C13, samp.WGR, samp.MPB, samp.HT.C13, samp.WGR.MPB,
     file = "driftsel_output1.RData")
load("E:/Conifers/output_selection/driftsel_afm.RData")

#Neutrality test for the posteriors obtained from MH (S.test == neut.test())
S.test(samp$pop.ef, samp$G, samp$theta)# neutrality test
S.test(samp$pop.ef, samp$G, samp$theta, G.off=TRUE) # ignore genetic correlations?
S.test(samp$pop.ef, samp$G, samp$theta, th.off=TRUE) # ignore signatures of gene flow?

viz.theta(afm$theta) # based only on molecular markers
viz.theta(samp$theta) # based on molecular markers & phenotype

#get 95% CI for theta (coancestry coefficients)
coanc = round(apply(theta,1:2,mean),3)
round(apply(theta,1:2,function(x) quantile(x,probs = c(0.025,0.975))),3)


par(mfrow=c(1,2), mar=c(4,3,2,1))
plot(afm$fst, t='l', main="Trace of Fst", xlab = 'Iterations', ylab = '')
plot(density(afm$fst), main="Posterior density", ylab = '')
rug(afm$fst)
