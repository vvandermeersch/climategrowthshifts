##########################
###  Custom functions  ###
##########################

#' @author - Yang Liu
#' @description - composed in 2020 and revised in 2021

#' Function to adjust phenotype by removing design and spatial effects based on raw data 
#' @param dat - raw data containing raw phenotype measurements, site, provenance, pedigree and exp design information.
#' @param target.trait - a list providing traits for adjustment
#' @param rho.grid - a list providing grid search values
#' @param rhos - a list for best rhos after grid search; the structure is arrayed by site where rhos for all traits are placed for each site.
#' @param step - numeric value 1 or not 1 for the second step
#' @return a print indicating the analysis is completed.

PHENOADJUST = function(dat,target.trait,rho.grid=NULL,rhos=NULL,step){
  if(is.null(rho.grid)==TRUE && is.null(rhos)==TRUE){
    cat("Error: The required data are not fully supplied.")
    q('no')
  }
  
  for (i in 1:length(unique(dat$site))) {
    print(i)
    
    for (j in 1:length(target.trait)) {
      print(target.trait[j])
      
      dat$pheno = dat[,target.trait[j]]
      sousdat = dat %>%
        filter(site==i) %>%
        mutate(pheno=as.numeric(as.character(pheno))) %>% 
        drop_na(self, dad, mum, rep, set, pheno)
      
      if(nrow(sousdat) < 1){
        next
      }
      
      if(step==1){
        #run spatial model with fine-tuning grids
        res.ar.grid = remlf90(fixed = pheno ~ -1 + proc,
                              random = ~ rep + set,
                              genetic = list(model = 'add_animal', 
                                             pedigree = sousdat[, c('self','dad','mum')], 
                                             id = 'self'), 
                              spatial = list(model = 'AR', 
                                             coord = sousdat[, c('row','col')],
                                             rho = rho.grid),
                              data = sousdat, method = 'em')
        
        #save the results
        garder = file(paste("site",i,"_",target.trait[j],"_output.txt",sep = ""),"w")
        sink(garder); print(summary(res.ar.grid)); sink(); close(garder)
        
      } else {
        #run spatial model
        res.ar = remlf90(fixed = pheno ~ -1 + proc,
                         random = ~ rep + set,
                         genetic = list(model = 'add_animal', 
                                        pedigree = sousdat[, c('self','dad','mum')], 
                                        id = 'self'), 
                         spatial = list(model = 'AR', 
                                        coord = sousdat[, c('row','col')],
                                        rho = unlist(rhos[j+(i-1)*length(target.trait)])),
                         data = sousdat, method = 'em')
        
        #adjust phenotype by removing effects of rep, set, and autoregressive spatial residuals
        rep.pheno = model.matrix(res.ar)$rep %*% ranef(res.ar)$rep
        set.pheno = model.matrix(res.ar)$set %*% ranef(res.ar)$set
        sp.pheno = model.matrix(res.ar)$spatial %*%  ranef(res.ar)$spatial
        sousdat$phe2adj = sousdat$pheno - as.vector(rep.pheno) - as.vector(set.pheno) - as.vector(sp.pheno)
        sousdat$sp = as.vector(sp.pheno)
        sousdat$repl = as.vector(rep.pheno)
        sousdat$set1 = as.vector(set.pheno)
        
        sousdat = sousdat %>% dplyr::select(site,rep,set,proc,self,mum,dad,col,row,pheno,phe2adj,sp,repl,set1)
        
        #output the adjusted phenotype for subsequent use
        write.table(sousdat, row.names = FALSE, col.names = TRUE,
                    file = paste("site",i,"_",target.trait[j],"_adj.txt",sep = ""))
      }
    }
  }
  return(print('All is done!'))
}

############################
###  Modified functions  ###
############################
##RAFM functions originally written by Ovaskainen et al. with modifications shown below
#see reference: 
adjust.this = function(rates, props, w, a, dirichlet=TRUE){
  adjustment = exp(a*(rates - 0.44))
  if( dirichlet ){
    output = props / adjustment
    output[which(output>10^3)] = 10^3
    output[which(output<10^(-3))] = 10^(-3)
  }
  else{ # only Gaussian distribution in this case
    output = props*adjustment
  }
  return(output)
}

AFM = function(dat, nMC, burnin, thinning, eps=7, priq=1, pria=c(1,2), prik=1){
  # Allele counts
  dat = compress.data(dat)
  
  # Initial values
  epsilon = 10^(-eps)	
  nloci = length(dat)
  npop = nrow(dat[[1]])
  pAnc = dat
  z = dat
  logalpha = rnorm(npop, 1, sqrt(2))
  for( j in 1:nloci ){
    nal = ncol(dat[[j]])
    pAnc[[j]] = rdirtrunc(rep(1,nal), epsilon)
    for( i in 1:npop ){
      z[[j]][i,] = rdirtrunc(pAnc[[j]]*exp(logalpha[i]), epsilon)
    }
  }
  kap = matrix(0.2/(npop-1), ncol=npop, nrow=npop)
  diag(kap) = 0.8
  
  # Initial proposals
  propAnc = rep(10, nloci)
  propz = matrix(100, nrow=npop, ncol=nloci)
  propkap = rep(100, npop)
  propalpha = rep(0.1, npop)
  iterno = 0 # needed for adaptation only
  
  # Prior parameters
  prioralpha = pria
  priorkap = matrix(0.2/(npop-1), npop, npop)
  diag(priorkap) = 0.8
  priorkap = prik*priorkap
  priorAnc = pAnc
  for( j in 1:nloci ){
    priorAnc[[j]] = rep(priq, length(priorAnc[[j]]))
  }	
  
  # Initial likelihood
  clike1 = rep(0, nloci)
  clike2 = matrix(0, ncol=nloci, nrow=npop)
  clike3 = rep(0, npop)
  clike4 = rep(0, npop)
  clike5 = matrix(0, ncol=nloci, nrow=npop)
  for( j in 1:nloci ){
    clike1[j] = l1(pAnc[[j]], priorAnc[[j]], epsilon)
    for( i in 1:npop ){
      clike2[i,j] = l2(z[[j]][i,], logalpha[i], pAnc[[j]], epsilon)
      clike5[i,j] = l5(kap[i,], z[[j]], dat[[j]][i,])
    }
  }
  for( i in 1:npop ){
    clike3[i] = l3(logalpha[i], prioralpha)
    clike4[i] = l4(kap[i,], priorkap[i,], i, epsilon)
  }
  
  # Accept ratios
  acAnc = rep(0, nloci)
  acz = matrix(0, nrow=npop, ncol=nloci)
  ackap = rep(0, npop)
  acalpha = rep(0, npop)
  
  # Output variables
  output = c(kap, logalpha)
  
  # Monte Carlo loop
  for( i in 1:nMC ){
    
    # Status
    if( round(i/100)==i/100 ){
      print(paste("iter", i), quote=F)
    }
    iterno = iterno + 1
    adjust = (i <= burnin)
    
    # Updating ancestral frequencies
    for( j in 1:nloci ){
      oldlike = clike1[j] + sum(clike2[,j])
      oldp = pAnc[[j]]
      newp = rdirtrunc(propAnc[j]*oldp, epsilon)
      nl1 = l1(newp, priorAnc[[j]], epsilon)
      nl2 = rep(0, npop)
      for( i in 1:npop ){
        nl2[i] = l2(z[[j]][i,], logalpha[i], newp, epsilon)
      }
      there = ddirtrunc(newp, propAnc[j]*oldp, epsilon, log=T)
      here = ddirtrunc(oldp, propAnc[j]*newp, epsilon, log=T)
      accept = nl1 + sum(nl2) + here - oldlike - there
      if( is.nan(accept) ){ accept = -Inf }
      if( log(runif(1,0,1)) < accept ){
        pAnc[[j]] = newp
        clike1[j] = nl1
        clike2[,j] = nl2
        acAnc[j] = acAnc[j] + 1
      }
    }
    
    # Updating kappa
    for( i in 1:npop ){
      oldkap = kap[i,]
      newkap = rdirtrunc(oldkap*propkap[i], epsilon)
      oldlike = clike4[i] + sum(clike5[i,])
      nl4 = l4(newkap, priorkap[i,], i, epsilon)
      nl5 = rep(0, nloci)
      for( j in 1:nloci ){
        nl5[j] = l5(newkap, z[[j]], dat[[j]][i,])
      }
      here = ddirtrunc(oldkap, propkap[i]*newkap, epsilon)
      there = ddirtrunc(newkap, propkap[i]*oldkap, epsilon)
      accept = nl4 + sum(nl5) + here - oldlike - there
      if( is.nan(accept) ){ accept = -Inf }
      if( log(runif(1,0,1)) < accept ){
        kap[i,] = newkap
        clike4[i] = nl4
        clike5[i,] = nl5
        ackap[i] = ackap[i] + 1
      }
    }		
    
    # Updating alpha
    for( i in 1:npop ){
      olda = logalpha[i]
      newa = rnorm(1, olda, propalpha[i])
      oldlike = clike3[i] + sum(clike2[i,])
      nl3 = l3(newa, prioralpha)
      nl2 = rep(0, nloci)
      for( j in 1:nloci ){
        nl2[j] = l2(z[[j]][i,], newa, pAnc[[j]], epsilon)
      }
      accept = nl3 + sum(nl2) - oldlike # symmetric
      if( is.nan(accept) ){
        accept = -Inf 
      }
      if( log(runif(1,0,1)) < accept ){
        logalpha[i] = newa
        clike2[i,] = nl2
        clike3[i] = nl3
        acalpha[i] = acalpha[i] + 1
      }
    }
    
    # Updating frequencies in lineages
    for( j in 1:nloci ){
      for( i in 1:npop ){
        oldlike = clike2[i,j] + sum(clike5[,j])
        oldz = z[[j]][i,]
        newz = rdirtrunc(propz[i,j]*oldz, epsilon)
        nl2 = l2(newz, logalpha[i], pAnc[[j]], epsilon)
        nl5 = rep(0, npop)
        Z = z[[j]]
        Z[i,] = newz
        for( k in 1:npop ){
          nl5[k] = l5(kap[k,], Z, dat[[j]][k,])
        }
        here = ddirtrunc(oldz, propz[i,j]*newz, epsilon)
        there = ddirtrunc(newz, propz[i,j]*oldz, epsilon)
        accept = nl2 + sum(nl5) + here - oldlike - there
        if( is.nan(accept) ){ accept = -Inf }
        if( log(runif(1,0,1)) < accept ){
          z[[j]][i,] = newz
          clike2[i,j] = nl2
          clike5[,j] = nl5
          acz[i,j] = acz[i,j] + 1
        }
      }
    }
    output = rbind(output, c(kap, logalpha)) # output variable
    
    # Adjusting proposals
    if( adjust ){
      w = 1 - 0.1*exp(-i/1000)
      a = 0.1*exp(-i/1000)
      iterno = w*iterno
      ackap = w*ackap
      acAnc = w*acAnc
      acz = w*acz
      acalpha = w*acalpha
      ratekap = ackap / iterno
      rateAnc = acAnc / iterno
      ratez = acz / iterno
      ratealpha = acalpha / iterno
      propkap = adjust.this(ratekap, propkap, w, a)
      propAnc = adjust.this(rateAnc, propAnc, w, a)
      propz = adjust.this(ratez, propz, w, a)
      propalpha = adjust.this(ratealpha, propalpha, w, a, dirichlet=FALSE)
    }	
  }
  
  # Burnin & thinning
  output = output[(burnin+1):nMC,]
  imax = floor(nrow(output) / thinning)
  totake = thinning*1:imax
  output = output[totake,]
  
  # Data out
  nmc_ = nrow(output)
  nc = ncol(output)
  kapm = array(NA, dim=c(npop, npop, nmc_))
  alpham = array(NA, dim=c(npop, nmc_))
  for( i in 1:nmc_ ){
    kapm[,,i] = matrix(output[i,1:(npop^2)], ncol=npop, nrow=npop)
    logalpha = output[i,(npop^2+1):nc]
    alpham[,i] = logalpha
  }
  print("posteriors written", quote=F)
  return(list(kapm,alpham))
}

CDFTruncatedBeta = function(x, alpha, beta, a, b){
  F = (pbeta(x, alpha, beta) - pbeta(a, alpha, beta)) / (pbeta(b, alpha, beta) - pbeta(a, alpha, beta))
  return(F)
}

compress.data = function(rawDat){
  pops = rawDat[,1]
  DNA = rawDat[,2:ncol(rawDat)]
  dna = matrix(NA, ncol=ncol(DNA)/2, nrow=2*nrow(DNA))
  for( i in 1:(ncol(DNA)/2) ){
    dna[,i] = c(DNA[,2*i], DNA[,-1+2*i])
  }
  pops = rep(pops, 2)
  uniqs = unique(pops)
  nloci = ncol(dna)
  dat = list(1:nloci)
  for( j in 1:nloci ){
    dnaj = dna[,j]
    nas = which(is.na(dnaj))
    if( length(nas) > 0 ){
      dnaj = dnaj[-nas]
      popsj = pops[-nas]
    }
    else{ popsj = pops }
    genotypes = c(unique(dnaj), "unobs")
    datj = matrix(0, nrow=length(uniqs), ncol=length(genotypes))
    for( p in 1:length(uniqs) ){
      thispop = dnaj[which(popsj==uniqs[p])]
      datj[p, ] = sapply(genotypes, function(x) length(which(thispop==x)))
    }
    dat[[j]] = datj
  }
  return(dat)
}

ddirtrunc = function(x, alpha, epsilon, log=TRUE){
  n = length(alpha)
  b = 1
  at = n*epsilon
  bt = n
  alphat = sum(alpha)
  xi = max(c( epsilon, 1-bt+b ))
  eta = min(c( b, 1-at+epsilon ))
  p = logPDFTruncatedBeta(x[n-1], alpha[n-1], alphat-alpha[n-1], xi, eta, epsilon)
  if( n > 2 ){
    for( k in (n-2):1 ){
      xi = max(c( epsilon/(1 - sum(x[(k+1):(n-1)])) , 1 - (bt - b*(n-k)) / (1-sum(x[(k+1):(n-1)])) ))
      eta = min(c( b/(1 - sum(x[(k+1):(n-1)])) , 1 - (at - epsilon*(n-k)) / (1-sum(x[(k+1):(n-1)])) ))
      tmp = x[k] / (1-sum(x[(k+1):(n-1)]))
      p = p + logPDFTruncatedBeta(tmp, alpha[k], alphat - sum(alpha[k:(n-1)]), xi, eta, epsilon)
    }
    for( k in (n-2):1 ){
      p = p - log(1 - sum(x[(k+1):(n-1)]))
    }
  }	
  if( !log ){ p = exp(p) }
  return(p)
}

# The workhorse
#	
do.all = function(dat, nMC, burnin, thinning, eps=7, priq=1, pria=c(1,2), prik=1){
  primary = AFM(dat, nMC, burnin, thinning, eps=7, priq=1, pria=c(1,2), prik=1)
  kap = primary[[1]]
  alpha = primary[[2]]
  secondary = gen.theta(kap, alpha)
  theta = secondary[[1]]
  fst = secondary[[2]]
  alpha = exp(alpha)
  npop = dim(theta)[1]
  print("Drawing trace of coancestry matrix theta, assess convergence.", quote=F)
  if( npop > 5 ){ 
    npop = 5
    print("N.B. Omitting populations 6+ from graph.", quote=F)
  }
  windows()
  par(mfcol=c(npop,npop))
  for( i in 1:npop ){
    for( j in 1:npop ){
      headl = paste("theta[ ",i," , ",j," ]", sep="")
      plot( theta[i,j,], type='l', main=headl, xlab="", ylab="" )
    }
  }
  out = as.list(1:4)
  names(out) = c("theta", "fst", "kappa", "alpha")
  out[[1]] = theta
  out[[2]] = fst
  out[[3]] = kap
  out[[4]] = alpha
  return(out)
}	

gen.fst = function(theta){
  npop = ncol(theta)
  offdiag = (sum(theta) - sum(diag(theta))) / (npop^2 - npop)
  fst = (mean(diag(theta)) - offdiag) / (1 - offdiag)
  return(fst)
}

gen.theta = function(kapm, alpham){
  # Eq. 12, Karhunen & Ovaskainen
  alpham = exp(alpham) # away from log-normal scale
  fstm = rep(NA, ncol(alpham))
  thetam = array(NA, dim=dim(kapm))
  npop = nrow(alpham)
  for( i in 1:length(fstm) ){
    kap = kapm[,,i]
    alpha = alpham[,i]
    theta = matrix(NA, nrow=npop, ncol=npop)
    for( j in 1:npop ){
      for( k in 1:j ){
        theta[k,j] = sum( kap[k,]*kap[j,] / (alpha + 1) )
        theta[j,k] = theta[k,j]
      }
    }
    thetam[,,i] = theta
    fstm[i] = gen.fst(theta)
  }
  
  return(list(thetam, fstm))
}

heat.theta = function(thetapost, mean=TRUE, verbose=TRUE){
  mod = as.matrix(0*thetapost[,,1])
  central = lower = upper = mod
  npop = dim(thetapost)[1]
  for( i in 1:npop ){
    for( j in 1:npop ){
      X = thetapost[i,j,]
      lower[i,j] = lower[j,i] = quantile(X, 0.025)
      upper[i,j] = upper[j,i] = quantile(X, 0.975)
      if( mean ){ 
        central[i,j] = central[j,i] = mean(X)
      }
      else{ central[i,j] = central[j,i] = median(X) }
    }
  }
  central = 0.5*(central + t(central))
  lower = 0.5*(lower + t(lower))
  upper = 0.5*(upper + t(upper))
  out = as.list(1:3)
  out[[1]] = central
  out[[2]] = lower
  out[[3]] = upper
  names(out) = c("mean", "lower", "upper")
  if( !mean ){
    names(out)[1] = "median"
  }
  heatmap(central, symm=T, margins=c(5,5), xlab="subpopulations, note permutation", ylab="", main="Coancestry matrix")
  if( verbose ){
    return(out)
  }
}

l1 = function(p_, priorAnc_, epsilon){
  return(ddirtrunc(p_, priorAnc_, epsilon, log=TRUE))
}

l2 = function(z_, logalpha_, p_, epsilon){
  return(ddirtrunc(z_, exp(logalpha_)*p_, epsilon, log=TRUE))
}

l3 = function(logalpha_, prioralpha_){
  return(dnorm(logalpha_, prioralpha_[1], sqrt(prioralpha_[2]), log=TRUE))
}

l4 = function(kap_, priorkap_, i_, epsilon){
  if( max(kap_)==kap_[i_] ){
    f = ddirtrunc(kap_, priorkap_, epsilon, log=TRUE)
  }
  else{ f = -Inf }
  return(f)	
}

l5 = function(kap_, z_, dat){
  K = matrix(kap_, nrow=nrow(z_), ncol=ncol(z_))
  p = apply(K*z_, 2, sum)
  f = dmultinom(dat, size=sum(dat), prob=p, log=TRUE)
  return(f)
}

logBeta = function(a){
  return( sum(lgamma(a)) - lgamma(sum(a)) )
}

logPDFDirichlet = function(x, a){
  return( sum((a-1)*log(x)) - logBeta(a) )
}

logPDFTruncatedBeta = function(x, alpha, beta, a, b, eps){
  if( x < a || x > b ){
    f = -Inf
  }
  else{	
    f = (alpha-1)*log(x) + (beta-1)*log(1-x) - logBeta(c(alpha,beta))
    normalizing = log(pbeta(b, alpha, beta) - pbeta(a, alpha, beta))
    if( normalizing == -Inf ){ # no place for x to move between a and b
      f = 0
    }
    else{
      f = f - normalizing
    }
  }
  return(f)
}

RandomDirichlet = function(a){
  eps = 10^(-7)
  x = rgamma(length(a), a)
  if( max(x) < 10^(-100) ){
    x = rep(0, length(a))
    x[sample(1:length(x))] = 1
  }
  x = x / sum(x)
  x[which(x<eps)] = eps
  x[which(x>1-eps)] = 1 - eps
  x = x / sum(x)
  return(x)
}

RandomTruncatedBeta = function(alpha, beta, a, b){
  quantil = pbeta(a, alpha, beta) + runif(1,0,1)*(pbeta(b, alpha, beta) - pbeta(a, alpha, beta))
  x = qbeta(quantil, alpha, beta)
  return(x)
}

rdirtrunc = function(alpha, epsilon){
  n = length(alpha)
  at = n*epsilon
  bt = n
  b = 1
  alphat = sum(alpha)
  x = rep(0,n)
  xi = max(c(epsilon, 1 - bt + b))
  eta = min(c(b, 1 - at + epsilon))
  x[n-1] = RandomTruncatedBeta(alpha[n-1], alphat-alpha[n-1], xi, eta)
  if( n > 2 ){
    for( k in (n-2):1 ){
      xi = max(c( epsilon/(1-sum(x[(k+1):(n-1)])) , 1 - (bt - b*(n-k))/(1 - sum(x[(k+1):(n-1)])) ))
      eta = min(c( b/(1-sum(x[(k+1):(n-1)])) , 1 - (at - epsilon*(n-k))/(1 - sum(x[(k+1):(n-1)])) ))
      tmp = RandomTruncatedBeta(alpha[k], alphat - sum(alpha[k:(n-1)]), xi, eta)
      x[k] = tmp*(1 - sum(x[(k+1):(n-1)]))
    }
  }
  x[n] = 1 - sum(x)
  x[which(x<epsilon)] = epsilon
  x[which(x>b)] = b
  return(x)
}

viz.theta = function(thetapost, distance=T, center=F, main=NA){
  # Multidimensional scaling
  npop = dim(thetapost)[1]
  theta = D = matrix(NA, npop, npop)
  for( i in 1:npop ){
    for( j in 1:i ){
      theta[i,j] = theta[j,i] = mean(thetapost[i,j,])
    } }
  for( i in 1:npop ){
    for( j in 1:i ){
      D2 = 2*(theta[i,i] + theta[j,j] - 2*theta[i,j])
      D[i,j] = D[j,i] = sqrt(D2)
    } }
  D = rbind(D, sqrt(2*diag(theta)))
  D = cbind(D, c(sqrt(2*diag(theta)), 0))
  D = sqrt(2/pi)*D # scaling SD -> E absolute value
  fit = cmdscale(D, k=2)
  if( center ){ fit[nrow(fit),] = c(0,0) }
  
  # Plotting
  if( is.na(main) ){
    main = "Expected drift distances (units of ancestral SD)"
    if( !is.na(distance) ){
      if( !distance ){
        main = "Population-level coancestry"
      }
    }
  }	
  eps = max(abs(fit))*0.1
  M = max(abs(fit)) + eps
  cx1 = 1 - 1*is.na(distance)
  plot(fit[,1], fit[,2], ylab="MDS 2", main=main, pch=16, xlim=c(-M,M), ylim=c(-M,M), axes=T, xlab="MDS 1", cex=cx1)
  eps = max(abs(fit))*0.1
  colvec = 1:9
  colvec[7] = "orange"
  colvec[9] = "chartreuse"
  eps = (1 - 1*is.na(distance))*eps
  text(fit[1:npop,1]+eps, fit[1:npop,2], 1:npop, col=colvec)
  text(fit[npop+1,1]+eps, fit[npop+1,2], "A")
  
  # Distance information
  if( !is.na(distance) ){
    for( i in 1:(npop+1) ){
      for( j in 1:(npop+1) ){
        lines(c(fit[i,1],fit[j,1]), c(fit[i,2], fit[j,2]))
      }
    }	
    eps = 0.8*eps
    if( distance ){ dd = round(D,2) }
    else{
      self = diag(theta)
      dd = rbind(theta,self)
      dd = cbind(dd,c(self,0))
      dd = round(dd,2)
    }
    for( i in 1:nrow(fit) ){
      if( i>1 ){
        for( j in 1:(i-1) ){
          text(0.5*(fit[i,1]+fit[j,1]), 0.5*(fit[i,2]+fit[j,2])+eps, dd[i,j], cex=0.75)			
        }
      }
    }
  }
}

viz.theta.exact = function(thetapost, distance=T, center=F, main=NA){
  # Multidimensional scaling
  nmc = dim(thetapost)[3]
  npop = dim(thetapost)[1]
  fit = matrix(0, ncol=2, nrow=npop+1)
  for( k in 1:nmc ){
    npop = dim(thetapost)[1]
    theta = D = matrix(NA, npop, npop)
    for( i in 1:npop ){
      for( j in 1:i ){
        theta[i,j] = theta[j,i] = thetapost[i,j,k]
      } }
    for( i in 1:npop ){
      for( j in 1:i ){
        D2 = 2*(theta[i,i] + theta[j,j] - 2*theta[i,j])
        D[i,j] = D[j,i] = sqrt(D2)
      } }
    D = rbind(D, sqrt(2*diag(theta)))
    D = cbind(D, c(sqrt(2*diag(theta)), 0))
    D = sqrt(2/pi)*D # scaling SD -> E absolute value
    fitk = cmdscale(D, k=2)
    if( center ){ fitk[nrow(fitk),] = c(0,0) }
    fit = fit + fitk / nmc # gradually towards mean
  }
  
  # Plotting
  if( is.na(main) ){
    main = "Expected drift distances (units of ancestral SD)"
    if( !is.na(distance) ){
      if( !distance ){
        main = "Population-level coancestry"
      }
    }
  }	
  eps = max(abs(fit))*0.1
  M = max(abs(fit)) + eps
  cx1 = 1 - 1*is.na(distance)
  plot(fit[,1], fit[,2], ylab="MDS 2", main=main, pch=16, xlim=c(-M,M), ylim=c(-M,M), axes=T, xlab="MDS 1", cex=cx1)
  eps = max(abs(fit))*0.1
  colvec = 1:9
  colvec[7] = "orange"
  colvec[9] = "chartreuse"
  eps = (1 - 1*is.na(distance))*eps
  text(fit[1:npop,1]+eps, fit[1:npop,2], 1:npop, col=colvec)
  text(fit[npop+1,1]+eps, fit[npop+1,2], "A")
  
  # Distance information
  if( !is.na(distance) ){
    for( i in 1:(npop+1) ){
      for( j in 1:(npop+1) ){
        lines(c(fit[i,1],fit[j,1]), c(fit[i,2], fit[j,2]))
      }
    }	
    eps = 0.8*eps
    if( distance ){ dd = round(D,2) }
    else{
      self = diag(theta)
      dd = rbind(theta,self)
      dd = cbind(dd,c(self,0))
      dd = round(dd,2)
    }
    for( i in 1:nrow(fit) ){
      if( i>1 ){
        for( j in 1:(i-1) ){
          text(0.5*(fit[i,1]+fit[j,1]), 0.5*(fit[i,2]+fit[j,2])+eps, dd[i,j], cex=0.75)			
        }
      }
    }
  }
}

######driftsel functions originally written by the with modifications shown below
#see reference: 

calc.blocks = function(blocks){
  blocks = as.matrix(blocks[,-1], nrow=nrow(blocks)) # IDs off
  nb = ncol(blocks)
  dimmat = nrow(blocks)
  output = array(0, dim=c(dimmat, dimmat, nb))
  for( i in 1:nb ){
    VB = matrix(0, ncol=dimmat, nrow=dimmat)
    levs = unique(blocks[,i])
    for( k in levs ){
      targ = which(blocks[,i]==k)
      VB[targ,targ] = 1
    }
    output[,,i] = VB
  }
  return(output)
}

calc.loads = function(ped, THP){
  n = nrow(ped)
  npop = ncol(THP)
  wpop = matrix(0, nrow=n, ncol=npop)
  
  # Founders
  founders = which(!is.na(ped[,4]))
  for( i in founders ){
    wpop[i,ped[i,4]] = wpop[i,ped[i,4]] + 1
  }
  
  # Offspring
  maxf = max(founders)
  for( i in (maxf+1):n ){
    s = ped[i,2] # id codes
    d = ped[i,3]
    s = min(which(ped[,1]==s)) # row numbers
    d = min(which(ped[,1]==d))
    wpop[i,] = 0.5*(wpop[s,] + wpop[d,]) # 'pure loading'		
  }
  
  # Out	
  return(wpop)
}

calc.M.alt = function(wpop, THP, ped){
  # Population-level effects
  n = nrow(wpop)
  npop = ncol(THP)
  Cov_pp = theta = matrix(0, n, n)
  for( i in 1:n ){
    for( j in 1:i ){
      Cov_pp[i,j] = t(wpop[i,]) %*% THP %*% wpop[j,]
      Cov_pp[j,i] = Cov_pp[i,j]
    }
  }
  
  # Total coancestry
  founders = which(!is.na(ped[,4]))
  for( i in founders ){
    for( j in 1:i ){
      if( i==j ){ 
        theta[i,j] = 0.5 + 0.5*THP[ped[i,4],ped[i,4]] 
      }
      else{ theta[i,j] = THP[ped[i,4],ped[j,4]] }
      theta[j,i] = theta[i,j]
    }
  }
  offs = which(is.na(ped[,4]))
  for( i in offs ){
    s = ped[i,2] # id codes
    d = ped[i,3]
    s = min(which(ped[,1]==s)) # row numbers
    d = min(which(ped[,1]==d))
    for( j in 1:i ){
      if( j<i ){
        theta[i,j] = 0.5*(theta[j,s] + theta[j,d])
      }
      else{ # self
        theta[i,i] = 0.5 + 0.5*theta[s,d]
      }
      theta[j,i] = theta[i,j]
    }
  }
  
  # Residual covariance
  M = theta - Cov_pp
  return(M)
}

calc.M = function(pars, THP, THB, censped){
  n = nrow(THB)
  dif = matrix(0, nrow=n, ncol=n)
  for( i in 1:n ){
    for( j in 1:i ){	
      x = 0
      if( (censped[i]+censped[j])==0 ){
        if( THB[i,j]>=0.25 ){ # full-sibs or self
          S = pars[i,3]
          D = pars[i,4]
          x = 0.125*( THP[S,S] + THP[D,D] )
          if( i==j ){ x = 2*x }
        }
        if( THB[i,j]==0.125 ){ # half-sibs
          if( pars[i,3]==pars[j,3] ){
            S = pars[i,3]
            x = 0.125*THP[S,S]
          }
          if( pars[i,4]==pars[j,4] ){
            D = pars[i,4]
            x = 0.125*THP[D,D]
          }
        }
      }
      dif[i,j] = dif[j,i] = x
    }
  }
  M = THB - dif	
  return(M)
}

calc.W.alt = function(wpop, covars, traits, THP){
  # Dimensions
  nt = ncol(traits)
  np = ncol(THP)
  nx = ncol(covars)
  n = nrow(covars)
  
  # Parental contributions
  indic = wpop
  
  # Censoring in covariates
  censed = which( apply(covars,1,function(x)length(which(is.na(x)))) > 0 )
  if( length(censed) > 0 ){
    nclass = apply(covars[-censed,,drop=F],2,function(x)length(unique(x)))	
    binaries = which(nclass<=2)
    covars[censed,-binaries] = 0
    covars[censed,1] = 1 # censored observations go to corner class
    for( j in binaries ){	
      covars[censed,j] = mean(covars[,j], na.rm=T) # can be either
    }
  }	
  
  # covars and indic are constants accross traits,
  # however they need to be changed into design matrices
  X = matrix(0, nrow=nt*n, ncol=nt*nx)
  Z = matrix(0, nrow=nt*n, ncol=nt*np)
  for( i in 1:nt ){
    lo = 1 + n*(i-1)
    hi = n*i
    lox = 1 + nx*(i-1)
    hix = nx*i
    loz = 1 + np*(i-1)
    hiz = np*i
    X[lo:hi,lox:hix] = covars
    Z[lo:hi,loz:hiz] = indic
  }
  
  W = cbind(X, Z)
  return(W)
}

calc.V = function(g, THP, G, priors){ # changes in the default application
  if( is.na(priors$fixed[[2]][1,1]) ){
    ng = length(g)
    n = ng - nrow(G)*nrow(THP)
    V = matrix(0, ncol=ng, nrow=ng)
    VF = 100*diag(n)
    Va = 2*G %x% THP
    V[1:n,1:n] = VF
    V[(n+1):ng,(n+1):ng] = Va # i.e. Va is a function of (G, THP)
  }
  else{ V = priors$fixed[[2]] }	
  return(V)
}

calc.W = function(pars, covars, traits, THP){
  # Dimensions
  nt = ncol(traits)
  np = ncol(THP)
  nx = ncol(covars)
  n = nrow(covars)
  
  # Parental contributions
  indic = matrix(0, ncol=np, nrow=n)
  for( i in 1:n ){
    if( !is.na(pars[i,3]) ){
      indic[i,pars[i,3]] = indic[i,pars[i,3]] + 0.5  
    }
    if( !is.na(pars[i,4]) ){
      indic[i,pars[i,4]] = indic[i,pars[i,4]] + 0.5
    }
  }
  
  # Censoring in covariates
  censed = which( apply(covars,1,function(x)length(which(is.na(x)))) > 0 )
  if( length(censed) > 0 ){
    nclass = apply(covars[-censed,,drop=F],2,function(x)length(unique(x)))	
    binaries = which(nclass<=2)
    covars[censed,-binaries] = 0
    covars[censed,1] = 1 # censored observations go to corner class
    for( j in binaries ){	
      covars[censed,j] = mean(covars[,j], na.rm=T) # can be either
    }
  }
  
  # covars and indic are constants accross traits,
  # however they need to be changed into design matrices
  X = matrix(0, nrow=nt*n, ncol=nt*nx)
  Z = matrix(0, nrow=nt*n, ncol=nt*np)
  for( i in 1:nt ){
    lo = 1 + n*(i-1)
    hi = n*i
    lox = 1 + nx*(i-1)
    hix = nx*i
    loz = 1 + np*(i-1)
    hiz = np*i
    X[lo:hi,lox:hix] = covars
    Z[lo:hi,loz:hiz] = indic
  }
  
  W = cbind(X, Z)
  return(W)
}

check.check = function(X, limes){
  solve(X/limes)
  solve(X*limes)
  return(FALSE) # this replaces TRUE which indicates problems
}

check.order = function(traits, binary){
  if( !is.na(binary) ){
    if( length(binary) < ncol(traits) ){
      guide = 1:ncol(traits)
      nonbin = guide[-binary]
      if( min(binary) < max(nonbin) ){
        print("Order of traits changed in output for computational convenience,", quote=F)
        print("present order:", quote=F) 
        print(guide[c(nonbin,binary)])
        print("N.B. G matrix, pop.ef, etc.", quote=F)
      }
    }
  }
}

const.sig = function(E, VR, G, M, blocks, Blist, bbit, sparse){
  Sig = (2*G %x% M) + (E %x% VR) # so far so good
  if( bbit ){
    for( i in 1:(dim(blocks)[3]) ){
      VB = blocks[,,i]
      if( sparse ){
        VB = as.matrix.csr(VB)
      }
      Sig = Sig + (Blist[,,i] %x% VB)
    }
  }
  return(Sig)
}

convert.2 = function(dat, dd, nb){
  nn = nrow(dat)
  out2 = list(1:nb)
  for( k in 1:nb ){
    outthis = array(NA, dim=c(dd, dd, nn))
    targ = ((k-1)*dd^2) + 1:(dd^2)
    datthis = dat[,targ,drop=F]
    for( i in 1:nn ){
      outthis[,,i] = matrix(datthis[i,], nrow=dd, ncol=dd)
    }
    out2[[k]] = outthis
  }
  return(out2)
}

convert = function(dat, dimy, npop, dimx){
  out = list(1:5)
  n = nrow(dat)
  out[[1]] = array(NA, dim=c(dimx, dimy, n))
  out[[2]] = array(NA, dim=c(npop, dimy, n))
  out[[3]] = array(NA, dim=c(dimy, dimy, n))
  out[[4]] = array(NA, dim=c(dimy, dimy, n))
  out[[5]] = array(NA, dim=c(npop, npop, n))
  for( i in 1:n ){
    dati = dat[i,]
    out[[1]][,,i] = matrix(dati[1:(dimx*dimy)], nrow=dimx)
    dati = dati[-(1:(dimx*dimy))]
    out[[2]][,,i] = matrix(dati[1:(npop*dimy)], nrow=npop)
    dati = dati[-(1:(npop*dimy))]
    out[[3]][,,i] = matrix(dati[1:(dimy*dimy)], nrow=dimy)
    dati = dati[-(1:(dimy*dimy))]
    out[[4]][,,i] = matrix(dati[1:(dimy*dimy)], nrow=dimy)
    dati = dati[-(1:(dimy*dimy))]
    out[[5]][,,i] = matrix(dati[1:(npop*npop)], nrow=npop)		
  }
  names(out) = c("fixed.ef","pop.ef","G","E","theta")
  return(out)
}

diwish_ = function(x, v, S, log=F){
  f = diwish(x, v, S)
  if( log ){
    f = log(f)
  }
  f = max(c(f, -1.0e280))
  return(f)
}

dwish_ = function(x, v, S, log=F){ # non-normalized!
  S = as.matrix(S)
  x = as.matrix(x)
  S_ = pseudoinverse(S) # to avoid numerical singularity
  p = ncol(x)
  f = rep(NA,3)
  f[1] = 0.5*(v-p-1)*log(det(x))
  f[2] = 0.5*sum(diag(S_%*%x))
  f[3] = 0.5*v*log(det(S))
  f[which(f>1.0e280)] = 1.0e280
  f[which(f<(-1.0e280))] = -1.0e280
  f = f[1] - f[2] - f[3]
  if( !log ){
    f = exp(f)
  }
  return(f)
}

ellipsis = function(mu, Sig, prob.mass, lwd, col){
  radius = sqrt(qchisq(prob.mass, 2))
  theta = 2*pi*(0:360) / 360
  unit.circle = cbind(cos(theta), sin(theta))
  Q = base::chol(Sig, pivot=TRUE)
  order = order(attr(Q, "pivot"))
  ellipse = t(mu + radius * t(unit.circle %*% Q[, order]))
  lines(ellipse[,1], ellipse[,2], lwd=lwd, col=col)
}

H.test = function(popefpost, Gpost, THpost, env, silent=T){
  # Stupid scaling again
  nx = dim(popefpost)[1] * dim(popefpost)[2]
  npop = dim(THpost)[1]
  nmc = dim(THpost)[3]
  env = env[,-1] # removing ids
  env = into.dist(env)
  
  # Posterior of Mantel statistic for phenotypic distance
  mobs = mrand = rep(NA, nmc)
  for( i in 1:nmc ){
    G = Gpost[,,i] # G matrix
    theta = THpost[,,i] # theta	
    C2 = matrix(mvrnorm( 1, rep(0, nx), 2*G %x% theta ), nrow=npop)
    D2 = into.dist(popefpost[,,i]) # observed distance matrix		
    C2 = into.dist(C2) # distance matrix from neutral model
    mobs[i] = mantel.stat(D2, env) # observed product moment
    mrand[i] = mantel.stat(C2, env) # randomized product moment
  }
  
  # Fancy figures	
  if( !silent ){
    par(mfcol=c(1,2))
    plot(mobs, type='l', ylab="observed product moment", xlab="iteration", main="Convergence check")
    plot(mrand, type='l', ylab="product moment from neutral model", xlab="iteration", main="Convergence check")
  }
  
  out = length(which(mobs>mrand)) / length(mobs)
  return(out)
}

ind.theta = function(pars, censped){
  n = nrow(pars)
  th = matrix(0, nrow=n, ncol=n)
  for( i in 1:n ){
    for( j in 1:i ){
      x = 0
      if( i==j ){ x = 0.5 }
      else{
        if( (censped[i]+censped[j])==0 ){
          x = 0.125*( 1*(pars[i,1]==pars[j,1]) + 1*(pars[i,2]==pars[j,2]) )
        }
      }	
      th[i,j] = th[j,i] = x
    }
  }
  return(th)
}

into.dist = function(covars){
  if( is.vector(covars) ){ covars = as.matrix(covars) }
  npop = nrow(covars)
  D = matrix(NA, npop, npop)
  for( j in 1:npop ){
    for( k in 1:j ){
      D[j,k] = sqrt(sum( (covars[k,] - covars[j,])^2 ))
      D[k,j] = D[j,k]
    }
  }	
  return(D)
}

likelihood = function(y, g, W, cSig, sparse){
  mu = W %*% g
  f = mvdnorm.chol(y, mu, cSig, sparse, log=T)
  return(f)
}

mantel.stat = function(A, B){
  D = A*B
  out = 0
  for( i in 1:nrow(D) ){
    for( j in 1:i ){
      out = out + D[i,j] } }
  return(out)
}

MH = function(poster, ped, covars, traits, nmc, burnin, thin, blocks=NA, priors=NA, tmp=NA, binary=NA, alt=F){
  # Dependencies
  library(corpcor)
  library(MCMCpack)
  library(SparseM)
  
  # Automate conversion
  ped = as.matrix(ped)
  covars = as.matrix(covars)
  traits = as.matrix(traits)
  blocks = as.matrix(blocks)
  
  # Phenotypic data
  X = as.matrix(covars[,-1], ncol=ncol(covars)-1)
  X = cbind(1, X) # 1 for grand mean
  y = c(traits[,-1])
  N = length(y)
  cens = which(is.na(y))
  if( length(cens)>0 ){ y = y[-cens] }
  if( N>=200 ){ sparse = T } # sparse matrix tricks
  else{ sparse = F }
  
  # Coancestry matrix & the other 'Kroenecker matrix'
  nop = dim(poster)[1]
  if( max(poster)==0 ){ # Bayes spirit
    for( i in 1:(dim(poster)[3]) ){
      poster[,,i] = 10^(-4)*diag(nop)
    }
  }
  w = sample(1:(dim(poster)[3]), 1)
  ww = w
  THP = as.matrix(poster[,,w])
  if( alt ){ # one generation
    ped = ped[,-1]
    censped = apply(ped, 1, function(x)length(which(is.na(x))))		
    THB = ind.theta(ped, censped)
    M = calc.M(ped, THP, THB, censped)
  }
  else{
    wpop = calc.loads(ped, THP)
    M = calc.M.alt(wpop, THP, ped)
  }
  VR = diag(ncol(M))
  if( sparse ){
    M = as.matrix.csr(M)
    VR = as.matrix.csr(VR) 
  }
  
  # Fundamental covariance matrices
  traits = as.matrix(traits[,-1], ncol=ncol(traits)-1)
  ntr = ncol(traits)
  G = rwish(ntr, diag(ntr)/ntr) # rwish_ doesn't work yet
  E = rwish(ntr, diag(ntr)/ntr)
  
  # Treating random/block effects
  bbit = (length(blocks) > 1)
  if( bbit ){
    nb = ncol(blocks) - 1
    blocks = calc.blocks(blocks) # covariates into design matrices
    Blist = array(NA, dim=c(ntr, ntr, nb))
    for( i in 1:nb ){
      Blist[,,i] = rwish(ntr, diag(ntr)/ntr)
    }
  }
  else{ Blist = NA }
  
  # Covariance matrix
  Sig = const.sig(E, VR, G, M, blocks, Blist, bbit, sparse)
  if( length(cens)>0 ){ Sig = Sig[-cens,-cens] }
  if( sparse ){ 
    Sig = as.matrix.csr(Sig)
    if( is.na(tmp) ){ cSig = SparseM::chol(Sig) }
    else{ cSig = SparseM::chol(Sig, tmpmax=tmp) }
  }
  else{ cSig = base::chol(Sig) }
  
  # Default priors
  if( length(priors)==1 ){
    priors = as.list(1:4)
    names(priors) = c("fixed","G","E","random")
    ng = ncol(traits)*(ncol(THP)+ncol(X))
    priors[[1]] = list(rep(0,ng), matrix(NA,ncol=1,nrow=1)) # for g
    priors[[2]] = list(ntr+1, diag(ntr)/(ntr+1)) # for G
    priors[[3]] = list(ntr+1, diag(ntr)/(ntr+1)) # for E
    if( bbit ){
      priors[[4]] = as.list(1:nb)
      for( i in 1:nb ){ # for blocks stuff
        priors[[4]][[i]] = list(ntr+1, diag(ntr)/(ntr+1))
      }
    }
  }
  else{
    priors = priors
    names(priors) = c("fixed","G","E","random")
    priors$fixed[[2]] = as.matrix(priors$fixed[[2]])
  }
  
  # Design matrices
  g = rnorm(ncol(traits)*(ncol(THP)+ncol(X)), 0, sqrt(max(poster)))
  V = calc.V(g, THP, G, priors)
  if( alt ){ W = calc.W(ped, X, traits, THP) }
  else{ W = calc.W.alt(wpop, X, traits, THP) }
  if( length(cens)>0 ){ W = W[-cens,] }			
  
  # Treating non-normal variables
  if( !is.na(binary) ){
    y_ = y
    y = update.y(y_, NA, g, W, Sig, binary, ntr, first=T)
  }
  
  # Densities
  like = likelihood(y, g, W, cSig, sparse)
  priG = pri.GG(G, priors)
  priE = pri.E(E, priors)
  prig = pri.g(g, THP, G, sparse, priors)
  if( bbit ){
    priBlocks = sapply(1:nb, function(x) pri.B(Blist[,,x], x, priors))
  }
  
  output = c(g,G,E,THP)
  if( bbit ){
    out2 = c(Blist, recursive=T)
  }
  
  # Adjustment parameters
  dltG = dltE = 2*ncol(G)
  dltb = 1
  iterno <- Eup <- Gup <- bup <- 0
  if( bbit ){ 
    dltB = rep(2*ncol(G), nb) 
    Bup = rep(0, nb) # not to be confused with bup
  }
  else{ dltB = 10 }
  props = rep( 1/(dim(poster)[3]), dim(poster)[3] )
  
  
  # A MASSIVE MCMC LOOP starts -
  for( i in 1:nmc ){
    
    # Updating g, nicely packed
    V = calc.V(g, THP, G, priors)
    try(g = update.g(W, cSig, V, y, sparse, priors), silent=T) # numerical singularity causes fail
    like = likelihood(y, g, W, cSig, sparse)
    prig = pri.g(g, THP, G, sparse, priors)
    
    # Updating latent liabilities, if any
    if( !is.na(binary) ){ 
      y = update.y(y_, y, g, W, Sig, binary, ntr, first=F) 
      like = likelihood(y, g, W, cSig, sparse)
    }
    
    # Updating G, random walk
    newG = G
    try(newG = rwish_(dltG, G/dltG), silent=T)
    here = dwish_(G, dltG, newG/dltG, log=T)
    there = dwish_(newG, dltG, G/dltG, log=T)
    newpriG = pri.GG(newG, priors)	
    newprig = pri.g(g, THP, newG, sparse, priors)
    newSig = const.sig(E, VR, newG, M, blocks, Blist, bbit, sparse)
    if( length(cens)>0 ){ newSig = newSig[-cens,-cens] }
    if( sparse ){ 
      newSig = as.matrix.csr(newSig)
      if( is.na(tmp) ){ newcSig = SparseM::chol(newSig) }
      else{ newcSig = SparseM::chol(newSig, tmpmax=tmp) }
    }
    else{ newcSig = base::chol(newSig) }
    newlike = likelihood(y, g, W, newcSig, sparse)
    accept = newlike + newpriG + newprig + here - like - priG - prig - there
    a = log(runif(1,0,1))
    if( !is.na(accept) ){
      if( a < accept ){
        G = newG
        Sig = newSig
        cSig = newcSig
        like = newlike
        priG = newpriG
        prig = newprig
        Gup = Gup + 1
      }}
    
    # Updating E, random walk
    newE = E
    try(newE = rwish_(dltE, E/dltE), silent=T)
    here = dwish_(E, dltE, newE/dltE, log=T)
    there = dwish_(newE, dltE, E/dltE, log=T)
    newpriE = pri.E(newE, priors)
    newSig = const.sig(newE, VR, G, M, blocks, Blist, bbit, sparse)
    if( length(cens)>0 ){ newSig = newSig[-cens,-cens] }
    if( sparse ){ 
      newSig = as.matrix.csr(newSig)
      if( is.na(tmp) ){ newcSig = SparseM::chol(newSig) }
      else{ newcSig = SparseM::chol(newSig, tmpmax=tmp) }
    }
    else{ newcSig = base::chol(newSig) }
    newlike = likelihood(y, g, W, newcSig, sparse)
    accept = newlike + newpriE + here - like - priE - there
    a = log(runif(1,0,1))
    if( !is.na(accept) ){
      if( a < accept ){
        E = newE
        Sig = newSig
        cSig = newcSig
        like = newlike
        priE = newpriE
        Eup = Eup + 1
      }}
    
    # Updating theta, independence sampler
    if( runif(1,0,1) < 0.5 ){
      k = sample(1:(dim(poster)[3]), 1, prob=props)
    }
    else{ k = sample(1:(dim(poster)[3]), 1) }
    newTHP = as.matrix(poster[,,k])
    if( alt ){ newM = calc.M(ped, newTHP, THB, censped) }
    else{ newM = calc.M.alt(wpop, newTHP, ped) }
    if( sparse ){ newM = as.matrix.csr(newM) }
    newSig = const.sig(E, VR, G, newM, blocks, Blist, bbit, sparse)
    if( length(cens)>0 ){ newSig = newSig[-cens,-cens] }
    if( sparse ){ 
      newSig = as.matrix.csr(newSig)
      if( is.na(tmp) ){ newcSig = SparseM::chol(newSig) }
      else{ newcSig = SparseM::chol(newSig, tmpmax=tmp) }
    }
    else{ newcSig = base::chol(newSig) }
    newprig = pri.g(g, newTHP, G, sparse, priors)
    newlike = likelihood(y, g, W, newcSig, sparse)
    here = log(props[w] + 0.5)
    there = log(props[k] + 0.5)
    accept = newlike + newprig - like - prig + here - there	
    a = log(runif(1,0,1))
    if( !is.na(accept) ){
      if( a < accept ){	
        THP = newTHP
        M = newM
        Sig = newSig
        cSig = newcSig
        prig = newprig
        like = newlike
        w = k
      }}
    
    # Updating block/random effects, random walk
    if( bbit ){
      for( k in 1:nb ){
        newB = Blist
        try(newB[,,k] = rwish_(dltB[k], newB[,,k,drop=F]/dltB[k]), silent=T)
        here = dwish_(Blist[,,k], dltB[k], newB[,,k]/dltB[k], log=T)
        there = dwish_(newB[,,k], dltB[k], Blist[,,k]/dltB[k], log=T)
        newpri = pri.B(newB[,,k], k, priors)
        newSig = const.sig(E, VR, G, M, blocks, newB, bbit, sparse)
        if( length(cens)>0 ){ newSig = newSig[-cens,-cens] }
        if( sparse ){ 
          newSig = as.matrix.csr(newSig)
          if( is.na(tmp) ){ newcSig = SparseM::chol(newSig) }
          else{ newcSig = SparseM::chol(newSig, tmpmax=tmp) }
        }
        else{ newcSig = base::chol(newSig) }
        newlike = likelihood(y, g, W, newcSig, sparse)
        accept = newlike + newpri + here - like - priBlocks[k] - there
        a = log(runif(1,0,1))
        if( !is.na(accept) ){
          if( a < accept ){
            Blist = newB
            Sig = newSig
            cSig = newcSig
            like = newlike
            priBlocks[k] = newpri
            Bup[k] = Bup[k] + 1
          }}
      }		
    }
    
    # Adapting proposals of G, E, etc.
    iterno = iterno + 1
    if( i < burnin ){
      wgh = 1 - 0.1*exp(-i/1000)
      a = 0.1*exp(-i/1000)
      iterno = wgh*iterno	
      Gup = wgh*Gup
      Eup = wgh*Eup
      rateG = Gup / iterno
      rateE = Eup / iterno
      dltG_ = exp(a*(0.23 - rateG))*dltG
      dltE_ = exp(a*(0.23 - rateE))*dltE
      if( dltG_ > ntr ){
        if( dltG_ < 200 ){
          dltG = dltG_ } }
      if( dltE_ > ntr ){
        if( dltE_ < 200 ){
          dltE = dltE_ } }
      if( bbit ){
        for( i in 1:length(dltB) ){
          Bup[i] = wgh*Bup[i]
          rateB = Bup[i] / iterno
          dltB_ = exp(a*(0.23 - rateB))*dltB[i]
          if( dltB_ > ntr ){
            if( dltB_ < 200 ){
              dltB[i] = dltB_ }}
        }
      }
    }
    
    # Adapting proposal of theta
    ww = c(ww, w)
    if( i==burnin ){ props = study(ww, dim(poster)[3], maxpar=30) }
    
    # Info for user
    if( round(i/100)==i/100 ){ print(paste("iter",i), quote=F) }
    output = rbind(output, c(g,G,E,THP))
    if( bbit ){
      out2 = rbind(out2, c(Blist, recursive=T))
    }
  } # MC LOOP CLOSES
  
  
  # Thinning and burn-in
  output = output[(burnin+1):nrow(output),]
  imax = floor(nrow(output) / thin)
  totake = thin*1:imax
  if( length(totake>1) ){
    output = output[totake,]
  }	
  if( bbit ){
    out2 = out2[(burnin+1):nrow(out2),,drop=F]
    if( length(totake>1) ){
      out2 = out2[totake,,drop=F]
    }
  }
  
  # Conversion
  out = convert(output, ncol(traits), ncol(THP), ncol(X))
  if( bbit ){ 
    out2 = convert.2(out2, ncol(G), nb)
    out = list(out, out2)
    names(out) = c("main.result","block.ef")
  }
  
  return(out)	
}

mvdnorm.chol = function(x, mu, cSig, sparse, log=F){
  dif = x - mu
  if( sparse ){ 
    SS = t(dif) %*% SparseM::backsolve(cSig, dif)
  }
  else{ SS = t(dif) %*% xx(cSig, dif) }
  SS = c(as.matrix(SS))
  if( sparse ){
    f1 = -(cSig@log.det)
  }
  else{ f1 = - sum(log(diag(cSig))) }
  f1 = min(c( f1, 1.0e280 ))
  SS = max(c( SS, -1.0e280 ))
  f1 = max(c( f1, -1.0e280 ))
  f = f1 - 0.5*SS
  if( !log ){
    f = exp(f)
  }
  return(f)
}

mvdnorm = function(x, mu, Sig, log=F, invert=T, sparse=F){
  if( sparse ){
    cSig = SparseM::chol(Sig)
    f = mvdnorm.chol(x, mu, cSig, TRUE, log=T)
  }
  else{
    Sig_ = solve(Sig)
    SS = t(x - mu) %*% Sig_ %*% (x - mu)
    f1 = -0.5*log(det(Sig))
  }
  f1 = min(c( f1, 1.0e280 ))
  SS = max(c( SS, -1.0e280 ))
  f1 = max(c( f1, -1.0e280 ))
  f = f1 - 0.5*SS	
  if( !log ){
    f = exp(f)
  }
  return(f)
}

neut.test = function(popefpost, Gpost, THpost, silent=T, G.off=F, th.off=F, main=NA){
  # Turning off-diagonals off if needed
  if( th.off ){
    npop = dim(THpost)[1]
    if( npop>1 ){
      for( i in 2:npop ){
        for( j in 1:(i-1) ){
          THpost[i,j,] = THpost[j,i,] = 0 }}}}
  if( G.off ){
    ntrait = dim(Gpost)[1]
    if( ntrait > 1 ){
      for( i in 2:ntrait ){
        for( j in 1:(i-1) ){
          Gpost[i,j,] = Gpost[j,i,] = 0 }}}}
  
  # Mahalanobis!
  apost = popefpost
  nmc = dim(apost)[3]
  D = rep(NA, nmc)
  for( i in 1:nmc ){
    a = c(apost[,,i])
    G = Gpost[,,i]
    THP = THpost[,,i]
    Sig = 2*G %x% THP
    Sig_ = solve(Sig)
    mu = rep(0, length(a))
    D2 = t(mu - a) %*% Sig_ %*% (mu - a)
    D[i] = D2
  }
  
  # Posterior probabilities
  dfr = (dim(Gpost)[1])*(dim(apost)[1])
  cdf = pchisq(D, dfr)
  out = mean(cdf)
  if( !silent ){
    if( is.na(main) ){ main = "Posterior trace" }
    plot(cdf, xlab="iteration", ylab="signal of selection (S)", main=main, type='l', lwd=2, ylim=c(0,1))
    lines(c(-length(cdf),2*length(cdf)), rep(0.2,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.8,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.5,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.05,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.95,2), lty='dashed')		
  }
  return(out)
}

Nh = function(invSig, mu_Sig, sparse){
  C = base::chol(invSig)
  u = rnorm(length(mu_Sig))
  gg = solve(t(C), mu_Sig)
  fi = solve(C, gg)
  u_ = solve(C, u)
  x = fi + u_
  return(x)
}

optim.beta = function(gridx, gridy, maxpar=6){
  eps = (gridx[2] - gridx[1]) / 2
  grdim = maxpar*10
  arange = brange = (1:grdim) / 10
  errormat = matrix(NA, ncol=grdim, nrow=grdim)
  for( i in 1:grdim ){
    for( j in 1:grdim ){
      a = arange[i]
      b = brange[j]
      f = sapply( gridx, function(x) (pbeta(x+eps, a, b) - pbeta(x-eps, a, b)) )
      f = f / sum(f)
      errormat[i,j] = sum((f - gridy)^2)
    }
  }
  num = which(errormat==min(errormat))
  ai = as.integer(grdim*(num/grdim - floor(num/grdim)))
  if( ai==0 ){ ai = grdim }
  bi = ceiling(num/grdim)
  a = arange[ai]
  b = brange[bi]
  f = sapply( gridx, function(x) (pbeta(x+eps, a, b) - pbeta(x-eps, a, b)) )
  f = f / sum(f)
  out = c(a, b)
  return(out)
}

pri.B = function(B, k, priors){
  prithis = priors$random[[k]]
  f = dwish_(B, prithis[[1]], prithis[[2]], log=T)
  return(f)
}

pri.E = function(E, priors){
  f = dwish_(E, priors$E[[1]], priors$E[[2]], log=T)
  return(f)
}

pri.g = function(g, THP, G, spar, priors){
  V = calc.V(g, THP, G, priors)
  f = NA # unavoidable psd fix
  try(f = mvdnorm(g, priors$fixed[[1]], V, log=T, sparse=F), silent=T)
  return(f)
}

pri.GG = function(G, priors){
  f = dwish_(G, priors$G[[1]], priors$G[[2]], log=T)
  return(f)
}

reord = function(traits, binary){
  if( is.na(binary) ){
    out = traits
  }
  else{
    if( length(binary) < (ncol(traits) - 1) ){
      id = traits[,1]
      traits = traits[,-1]
      guide = 1:ncol(traits)
      nonbin = guide[-binary]
      out = traits[,c(nonbin, binary)]
      out = cbind(id, out)
    }
    else{
      out = traits
    }
  }    
  return(out)
}

riwish_ = function(v, S){
  sing = TRUE
  while( sing ){
    X = riwish(v, S)
    try(sing = check.check(X) , silent=T)
  }
  return(X)
}

rwish_ = function(v, S){
  limes = 200 # hard-coded maximal degree of freedom
  sing = TRUE
  while( sing ){
    X = rwish(v, S)
    try(sing = check.check(X, limes) , silent=T)
  }
  X = 0.5*(X + t(X))
  return(X)
}

S.test = function(popefpost, Gpost, THpost, silent=T, G.off=F, th.off=F, main=NA){
  # Turning off-diagonals off if needed
  if( th.off ){
    npop = dim(THpost)[1]
    if( npop>1 ){
      for( i in 2:npop ){
        for( j in 1:(i-1) ){
          THpost[i,j,] = THpost[j,i,] = 0 }}}}
  if( G.off ){
    ntrait = dim(Gpost)[1]
    if( ntrait > 1 ){
      for( i in 2:ntrait ){
        for( j in 1:(i-1) ){
          Gpost[i,j,] = Gpost[j,i,] = 0 }}}}
  
  # Mahalanobis!
  apost = popefpost
  nmc = dim(apost)[3]
  D = rep(NA, nmc)
  for( i in 1:nmc ){
    a = c(apost[,,i])
    G = Gpost[,,i]
    THP = THpost[,,i]
    Sig = 2*G %x% THP
    Sig_ = solve(Sig)
    mu = rep(0, length(a))
    D2 = t(mu - a) %*% Sig_ %*% (mu - a)
    D[i] = D2
  }
  
  # Posterior probabilities
  dfr = (dim(Gpost)[1])*(dim(apost)[1])
  cdf = pchisq(D, dfr)
  out = mean(cdf)
  if( !silent ){
    if( is.na(main) ){ main = "Posterior trace" }
    plot(cdf, xlab="iteration", ylab="signal of selection (S)", main=main, type='l', lwd=2, ylim=c(0,1))
    lines(c(-length(cdf),2*length(cdf)), rep(0.2,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.8,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.5,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.05,2), lty='dashed')
    lines(c(-length(cdf),2*length(cdf)), rep(0.95,2), lty='dashed')		
  }
  return(out)
}

scale.pop.ef = function(posterior){
  nmc = dim(posterior)[3]
  phenodist = as.list(1:nmc)
  npop = dim(posterior)[1]
  ntrait = dim(posterior)[2]
  nc = npop*ntrait
  phenodist = as.list( rep(NA,nmc) )
  for( i in 1:nmc ){
    D = matrix(NA, npop, npop)
    pheno = posterior[,,i]
    phenodist[[i]] = into.dist(pheno)
  }
  return(phenodist)
}

study.2 = function(whistory, maxk, maxpar=6){
  whistory = round(whistory/maxk, 1)
  gridx = (1:9)/10
  gridy = sapply(gridx, function(x) length(which(whistory==x)))
  gridy = gridy / sum(gridy)
  parvec = optim.beta(gridx, gridy, maxpar=maxpar)
  gridprop = (1:maxk) / (maxk+1)
  props = sapply(gridprop, function(x) dbeta(x, parvec[1], parvec[2]))
  props = props / sum(props)
  return(props)
}

study = function(whistory, maxk, maxpar=30){
  y = whistory / (maxk+1)
  arange = brange = (10:(10*maxpar)) / 10
  grdim = length(arange)
  likemat = matrix(NA, ncol=grdim, nrow=grdim)
  for( i in 1:grdim ){
    for( j in 1:grdim ){
      a = arange[i]
      b = brange[j]
      likemat[i,j] = sum(dbeta(y, a, b, log=T))
    }
  }
  num = which(likemat==max(likemat))
  ai = as.integer(grdim*(num/grdim - floor(num/grdim)))
  if( ai==0 ){ ai = grdim }
  bi = ceiling(num/grdim)
  a = arange[ai]
  b = brange[bi]
  gridprop = (1:maxk) / (maxk+1)
  props = sapply(gridprop, function(x) dbeta(x, a, b))
  props = props / sum(props)
  return(props)
}

trunc1 = function(U, mux, sdx, signx){
  gridx = (1:9999) / 10^4
  if( signx==-1 ){
    up = pnorm(0, mux, sdx)
    gridx = gridx*up
  }
  if( signx==1 ){
    lo = 1 - pnorm(0, mux, sdx)
    gridx = 1 - lo*gridx
  }
  vals = qnorm(gridx, mux, sdx)
  if( max(vals)==-Inf ){ vals = rep(-1.0e-07, 10^4) }
  else{ vals[which(vals==-Inf)] = min(vals[which(vals>-Inf)]) }
  if( min(vals)==Inf ){ vals = rep(1.0e-07, 10^4) }
  else{ vals[which(vals==Inf)] = max(vals[which(vals<Inf)]) }
  U = ceiling(9999*U)
  out = vals[U]
  return(out)
}

truncrnorm = function(n, mux, sdx, signx){ # inefficient, calculates bins n times; yet redundant
  out = sapply(1:n, function(x) trunc1(runif(1,0,1), mux, sdx, signx) )
  return(out)
}

update.g = function(W, cSig, V, y, sparse, priors){
  V_ = solve(V)
  if( sparse ){
    gam_ = (t(W) %*% SparseM::backsolve(cSig,W)) + V_
    gam_ = as.matrix(gam_)
    mu_sig = t(W) %*% SparseM::backsolve(cSig,matrix(y,ncol=1))
    mu_sig = mu_sig + V_ %*% priors$fixed[[1]]
    mu_sig = as.matrix(mu_sig)
  }
  else{
    gam_ = (t(W) %*% xx(cSig,W)) + V_
    mu_sig = t(W) %*% xx(cSig,matrix(y,ncol=1))
    mu_sig = mu_sig + V_ %*% priors$fixed[[1]]
  }
  g = Nh(gam_, mu_sig, sparse)
  return(g)
}

update.y = function(y_, y, g, W, Sig, binary, ntr, first=FALSE){
  # Basics
  mu = W %*% g
  nin = length(y) / ntr
  bins = NA
  for( b in binary ){
    binb = (1:nin) + (b-1)*nin
    bins = c(bins, binb)
  }
  bins = bins[-1]
  nonbins = (1:length(y))[-bins]
  
  # First iteration
  if( first ){
    y = y_
    for( i in bins ){
      if( y_[i]==1 ){ y[i] = 0.01 }
      if( y_[i]==0 ){ y[i] = -0.01 }
    }
  }
  
  # Other iterations
  else{
    y_[which(y_==0)] = -1 # sign for normal truncation
    y = y
    V = solve(Sig)
    V = as.matrix(V)
    Sig = as.matrix(Sig)
    for( j in bins ){
      B = -V[j,-j] / V[j,j]
      mu.j = mu[j] + B %*% (y[-j] - mu[-j])
      s2.j = Sig[j,j] - B %*% Sig[-j,j]
      if( s2.j <= 0 ){ s2.j = 1.0e-04 }
      y[j] = truncrnorm(1, mu.j, sqrt(s2.j), y_[j])
    }
  }		
  return(y)
}

viz.theta = function(thetapost, distance=T, center=F, main=NA){
  # Multidimensional scaling
  npop = dim(thetapost)[1]
  theta = D = matrix(NA, npop, npop)
  for( i in 1:npop ){
    for( j in 1:i ){
      theta[i,j] = theta[j,i] = mean(thetapost[i,j,])
    } }
  for( i in 1:npop ){
    for( j in 1:i ){
      D2 = 2*(theta[i,i] + theta[j,j] - 2*theta[i,j])
      D[i,j] = D[j,i] = sqrt(D2)
    } }
  D = rbind(D, sqrt(2*diag(theta)))
  D = cbind(D, c(sqrt(2*diag(theta)), 0))
  D = sqrt(2/pi)*D # scaling SD -> E absolute value
  fit = cmdscale(D, k=2)
  if( center ){ fit[nrow(fit),] = c(0,0) }
  
  # Plotting
  if( is.na(main) ){
    main = "Expected drift distances (units of ancestral SD)"
    if( !is.na(distance) ){
      if( !distance ){
        main = "Population-level coancestry"
      }
    }
  }	
  eps = max(abs(fit))*0.1
  M = max(abs(fit)) + eps
  cx1 = 1 - 1*is.na(distance)
  plot(fit[,1], fit[,2], ylab="MDS 2", main=main, pch=16, xlim=c(-M,M), ylim=c(-M,M), axes=T, xlab="MDS 1", cex=cx1)
  eps = max(abs(fit))*0.1
  colvec = 1:9
  colvec[7] = "orange"
  colvec[9] = "chartreuse"
  eps = (1 - 1*is.na(distance))*eps
  text(fit[1:npop,1]+eps, fit[1:npop,2], 1:npop, col=colvec)
  text(fit[npop+1,1]+eps, fit[npop+1,2], "A")
  
  # Distance information
  if( !is.na(distance) ){
    for( i in 1:(npop+1) ){
      for( j in 1:(npop+1) ){
        lines(c(fit[i,1],fit[j,1]), c(fit[i,2], fit[j,2]))
      }
    }	
    eps = 0.8*eps
    if( distance ){ dd = round(D,2) }
    else{
      self = diag(theta)
      dd = rbind(theta,self)
      dd = cbind(dd,c(self,0))
      dd = round(dd,2)
    }
    for( i in 1:nrow(fit) ){
      if( i>1 ){
        for( j in 1:(i-1) ){
          text(0.5*(fit[i,1]+fit[j,1]), 0.5*(fit[i,2]+fit[j,2])+eps, dd[i,j], cex=0.75)			
        }
      }
    }
  }
}

viz.theta.exact = function(thetapost, distance=T, center=F, main=NA){
  # Multidimensional scaling
  nmc = dim(thetapost)[3]
  npop = dim(thetapost)[1]
  fit = matrix(0, ncol=2, nrow=npop+1)
  for( k in 1:nmc ){
    npop = dim(thetapost)[1]
    theta = D = matrix(NA, npop, npop)
    for( i in 1:npop ){
      for( j in 1:i ){
        theta[i,j] = theta[j,i] = thetapost[i,j,k]
      } }
    for( i in 1:npop ){
      for( j in 1:i ){
        D2 = 2*(theta[i,i] + theta[j,j] - 2*theta[i,j])
        D[i,j] = D[j,i] = sqrt(D2)
      } }
    D = rbind(D, sqrt(2*diag(theta)))
    D = cbind(D, c(sqrt(2*diag(theta)), 0))
    D = sqrt(2/pi)*D # scaling SD -> E absolute value
    fitk = cmdscale(D, k=2)
    if( center ){ fitk[nrow(fitk),] = c(0,0) }
    fit = fit + fitk / nmc # gradually towards mean
  }
  
  # Plotting
  if( is.na(main) ){
    main = "Expected drift distances (units of ancestral SD)"
    if( !is.na(distance) ){
      if( !distance ){
        main = "Population-level coancestry"
      }
    }
  }	
  eps = max(abs(fit))*0.1
  M = max(abs(fit)) + eps
  cx1 = 1 - 1*is.na(distance)
  plot(fit[,1], fit[,2], ylab="MDS 2", main=main, pch=16, xlim=c(-M,M), ylim=c(-M,M), axes=T, xlab="MDS 1", cex=cx1)
  eps = max(abs(fit))*0.1
  colvec = 1:9
  colvec[7] = "orange"
  colvec[9] = "chartreuse"
  eps = (1 - 1*is.na(distance))*eps
  text(fit[1:npop,1]+eps, fit[1:npop,2], 1:npop, col=colvec)
  text(fit[npop+1,1]+eps, fit[npop+1,2], "A")
  
  # Distance information
  if( !is.na(distance) ){
    for( i in 1:(npop+1) ){
      for( j in 1:(npop+1) ){
        lines(c(fit[i,1],fit[j,1]), c(fit[i,2], fit[j,2]))
      }
    }	
    eps = 0.8*eps
    if( distance ){ dd = round(D,2) }
    else{
      self = diag(theta)
      dd = rbind(theta,self)
      dd = cbind(dd,c(self,0))
      dd = round(dd,2)
    }
    for( i in 1:nrow(fit) ){
      if( i>1 ){
        for( j in 1:(i-1) ){
          text(0.5*(fit[i,1]+fit[j,1]), 0.5*(fit[i,2]+fit[j,2])+eps, dd[i,j], cex=0.75)			
        }
      }
    }
  }
}

viz.traits = function(fixedpost, popefpost, Gpost, THpost, traits, siz=0.5, main=NA){
  # Posterior means
  fixedpost = fixedpost[1,traits,] # ancestral mean
  popefpost = popefpost[,traits,]
  Gpost = Gpost[traits,traits,]
  popef = matrix(NA, nrow=dim(popefpost)[1], ncol=dim(popefpost)[2])
  G = matrix(NA, nrow=dim(Gpost)[1], ncol=dim(Gpost)[2])
  TH = matrix(NA, nrow=dim(THpost)[1], ncol=dim(THpost)[2])
  mu = rep(NA, dim(Gpost)[1])
  for( i in 1:length(traits) ){
    mu[i] = mean(fixedpost[i,])
    for( j in 1:length(traits) ){ G[i,j] = mean(Gpost[i,j,]) }
    for( j in 1:dim(popefpost)[1] ){ popef[j,i] = mean(popefpost[j,i,]) } # this way
  }
  for( i in 1:nrow(TH) ){
    for( j in 1:ncol(TH) ){ TH[i,j] = mean(THpost[i,j,]) }
  }
  
  # Drawing
  npop = ncol(TH)
  ntr = length(traits)
  npop = nrow(popef)
  colvec = 1:9
  colvec[7] = "orange"
  colvec[9] = "chartreuse"		
  i = 1
  j = 2
  ei = mu[i]
  ej = mu[j]
  Gthis = matrix(c(G[i,i],G[i,j],G[j,i],G[j,j]), ncol=2)
  xlab = paste("trait", traits[i])
  ylab = paste("trait", traits[j])
  M = max(c( sqrt(2*G[i,i]*diag(TH)) , sqrt(2*G[j,j]*diag(TH)), popef ))
  plot(ei, ej, pch=16, cex=0, xlim=c(ei-M,ei+M), ylim=c(ej-M,ej+M), xlab=xlab, ylab=ylab, main=main)
  for( k in 1:npop ){
    mu = c(ei,ej)
    Sigma = 2*TH[k,k]*Gthis
    if( k > 9 ){ k = 1 + k%%8 }
    ellipsis(mu, Sigma, siz, 1, colvec[k])
  }
  text(ei+popef[,i], ej+popef[,j], 1:npop, cex=1, col=colvec)
  text(ei, ej, "A")
}

xx = function(cA, B){
  nc = ncol(B)
  product = matrix(NA, nrow=nrow(cA), ncol=ncol(B))
  for( j in 1:nc ){
    yep = solve(t(cA), B[,j])
    product[,j] = solve(cA, yep)
  }
  return(product)
}
